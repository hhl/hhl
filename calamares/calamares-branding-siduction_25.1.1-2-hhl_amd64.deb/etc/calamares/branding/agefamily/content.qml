import QtQuick 2.15
import QtQuick.Controls 2.15
import QtQuick.Layouts 1.15

Item {
    id: agefamilyItem
    property bool isFamilyAccount: false
    property bool disclaimerAccepted: false

    ColumnLayout {
        anchors.fill: parent
        spacing: 10

        Label {
            text: "Age and Family Information"
            font.bold: true
            font.pixelSize: 16
        }

        Label {
            text: "No real age verification (ID/CPF/birthdate) is performed."
            wrapMode: Label.Wrap
        }

        ComboBox {
            id: accountType
            Layout.fillWidth: true
            textRole: "label"
            model: [
                { value: "adult", label: "Adult account" },
                { value: "family", label: "Family / child account (under 18)" }
            ]

            onCurrentIndexChanged: {
                agefamilyItem.isFamilyAccount = currentText === "family";
            }
        }

        Label {
            text: (
                "<b>No personal data collected</b><br>" +
                "No ID, CPF, or birth date is stored.<br><br>" +
                "<b>Usage in Brazil</b><br>" +
                "This system is not designed to comply with the Brazilian " +
                "ECA Digital age verification law.<br>" +
                "If you use it in Brazil, you do so at your own responsibility.<br><br>" +
                "<i>Check the box below to confirm you understand this.</i>"
            )
            wrapMode: Label.Wrap
            color: "#444"
        }

        CheckBox {
            id: acceptBox
            text: "I understand that no real age verification is performed and that this system is not targeted at Brazil."

            onToggled: {
                agefamilyItem.disclaimerAccepted = checked;
            }
        }

        Button {
            text: "Accept and continue"
            Layout.fillWidth: true
            enabled: disclaimerAccepted

            onClicked: {
                // Speichere die Daten im System
                // In der Praxis nutzt du Calamares‑GlobalStorage‑API;
                // hier symbolisch:
                CalamaresJS.globalStorage.set("age_bracket", "age_undefined");
                CalamaresJS.globalStorage.set("is_family_account", isFamilyAccount);
                CalamaresJS.globalStorage.set("disclaimer_applied", true);
                CalamaresJS.next();   // zum nächsten Calamares‑Step
            }
        }
    }
}
